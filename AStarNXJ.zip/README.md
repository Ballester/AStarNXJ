# AStarNXC
AStar implementation in NXJ
nxjc AStar.java
nxj -r AStar
